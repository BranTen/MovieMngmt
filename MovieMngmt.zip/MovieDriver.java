		import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		Movie movie = new Movie();
	String title;
	String rating;
	String a = null;
	int soldTickets;
	do {
System.out.println("please enter the title of the movie: ");
title = in.nextLine();
movie.setTitle(title);
System.out.println("please enter the rating of the movie");
rating = in.nextLine();
movie.setRating(rating);
System.out.println("please enter the tickets sold ");
soldTickets = in.nextInt();
movie.setSoldTickets(soldTickets);
System.out.println(movie.toString());
System.out.println("do you want to enter another movie? (y/n)");
a = in.next();
in.nextLine();
	}
	while (a.equalsIgnoreCase("y"));
	in.close();
	}

}
